//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LedDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_LEDDEMTYPE                  129
#define IDB_LEDS                        130
#define IDD_TEST                        131
#define IDC_LED1                        1000
#define IDC_LED2                        1001
#define IDC_COLOR                       1002
#define IDC_LED4                        1002
#define IDC_RADIO2                      1003
#define IDC_LED5                        1003
#define IDC_RADIO3                      1004
#define IDC_LED6                        1004
#define IDC_RADIO4                      1005
#define IDC_LED7                        1005
#define IDC_LED3                        1006
#define IDC_LED8                        1007
#define IDC_MODE                        1008
#define IDC_RADIO7                      1009
#define IDC_RADIO8                      1010
#define IDC_PING                        1012
#define ID_TEST_LEDTESTDIALOG           32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
