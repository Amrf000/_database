// LedDemoView.cpp : implementation of the CLedDemoView class
//

#include "stdafx.h"
#include "LedDemo.h"

#include "LedDemoDoc.h"
#include "LedDemoView.h"
#include "TestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLedDemoView

IMPLEMENT_DYNCREATE(CLedDemoView, CView)

BEGIN_MESSAGE_MAP(CLedDemoView, CView)
	//{{AFX_MSG_MAP(CLedDemoView)
	ON_COMMAND(ID_TEST_LEDTESTDIALOG, OnTestLedtestdialog)
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLedDemoView construction/destruction

CLedDemoView::CLedDemoView()
{
	// TODO: add construction code here

}

CLedDemoView::~CLedDemoView()
{
}

BOOL CLedDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CLedDemoView drawing

void CLedDemoView::OnDraw(CDC* pDC)
{
	CLedDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// Center the Led in the window -- assumed led size is 16 X 16 pixels
	CRect rect;
	GetClientRect(&rect);
	m_Led.MoveWindow(rect.Width()/2 - 8,rect.Height()/2 - 8,16,16);
}

/////////////////////////////////////////////////////////////////////////////
// CLedDemoView diagnostics

#ifdef _DEBUG
void CLedDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CLedDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CLedDemoDoc* CLedDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLedDemoDoc)));
	return (CLedDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLedDemoView message handlers

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void CLedDemoView::OnTestLedtestdialog() 
{
	CTestDlg Dlg;
	Dlg.DoModal();
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
int CLedDemoView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	//
	// Create static ontrol
	//
	CRect rect(0,0,15,15);
	m_Led.Create(NULL,WS_CHILD | WS_VISIBLE, rect, this);

	//
	// Set intiial LED state
	//
	m_Led.SetLed(CLed::LED_COLOR_GREEN,CLed::LED_OFF,CLed::LED_ROUND);

	//
	// Set timer so led will flash 1/sec
	//
	SetTimer(1,1000,NULL);

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void CLedDemoView::OnTimer(UINT nIDEvent) 
{
	//
	// Ping led for 200 ms
	//
	m_Led.Ping(200);	

	CView::OnTimer(nIDEvent);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
BOOL CLedDemoView::OnEraseBkgnd(CDC* pDC) 
{
	//
	// Make this view a gray background
	//
	pDC->SelectStockObject(LTGRAY_BRUSH);
	CRect rect;
	GetClientRect(&rect);

	pDC->Rectangle(&rect);
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
