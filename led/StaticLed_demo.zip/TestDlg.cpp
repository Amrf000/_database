// TestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LedDemo.h"
#include "TestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestDlg dialog


CTestDlg::CTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestDlg)
	m_iColor = -1;
	m_iMode = -1;
	//}}AFX_DATA_INIT
}


void CTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestDlg)
	DDX_Control(pDX, IDC_LED3, m_Led3);
	DDX_Control(pDX, IDC_LED2, m_Led2);
	DDX_Control(pDX, IDC_LED1, m_Led1);
	DDX_Radio(pDX, IDC_COLOR, m_iColor);
	DDX_Radio(pDX, IDC_MODE, m_iMode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestDlg, CDialog)
	//{{AFX_MSG_MAP(CTestDlg)
	ON_BN_CLICKED(IDC_COLOR, OnUpdateLED)
	ON_BN_CLICKED(IDC_RADIO2, OnUpdateLED)
	ON_BN_CLICKED(IDC_RADIO3, OnUpdateLED)
	ON_BN_CLICKED(IDC_RADIO4, OnUpdateLED)
	ON_BN_CLICKED(IDC_MODE, OnUpdateLED)
	ON_BN_CLICKED(IDC_RADIO7, OnUpdateLED)
	ON_BN_CLICKED(IDC_RADIO8, OnUpdateLED)
	ON_BN_CLICKED(IDC_PING, OnPing)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDlg message handlers

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void CTestDlg::OnUpdateLED() 
{
	int iColor, iMode;
	UpdateData();

	switch(m_iColor)
	{
		case 0 : iColor = CLed::LED_COLOR_RED; break;
		case 1 : iColor = CLed::LED_COLOR_GREEN; break;
		case 2 : iColor = CLed::LED_COLOR_YELLOW; break;
		case 3 : iColor = CLed::LED_COLOR_BLUE; break;
	}

	switch(m_iMode)
	{
		case 0 : iMode = CLed::LED_ON; break;
		case 1 : iMode = CLed::LED_OFF; break;
		case 2 : iMode = CLed::LED_DISABLED; break;
	}

	m_Led1.SetLed(iColor,iMode,CLed::LED_ROUND);
	m_Led2.SetLed(iColor,iMode,CLed::LED_SQUARE);
	m_Led3.SetLed(iColor,CLed::LED_OFF,CLed::LED_ROUND);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
BOOL CTestDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CheckDlgButton(IDC_COLOR,TRUE);
	CheckDlgButton(IDC_MODE,TRUE);
	OnUpdateLED();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void CTestDlg::OnPing() 
{
	m_Led3.Ping(500);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
