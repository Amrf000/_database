// LedDemoDoc.h : interface of the CLedDemoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LEDDEMODOC_H__D5E9B2AB_710E_11D3_9047_00104B264545__INCLUDED_)
#define AFX_LEDDEMODOC_H__D5E9B2AB_710E_11D3_9047_00104B264545__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CLedDemoDoc : public CDocument
{
protected: // create from serialization only
	CLedDemoDoc();
	DECLARE_DYNCREATE(CLedDemoDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLedDemoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLedDemoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLedDemoDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LEDDEMODOC_H__D5E9B2AB_710E_11D3_9047_00104B264545__INCLUDED_)
