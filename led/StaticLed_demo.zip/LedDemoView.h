// LedDemoView.h : interface of the CLedDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LEDDEMOVIEW_H__D5E9B2AD_710E_11D3_9047_00104B264545__INCLUDED_)
#define AFX_LEDDEMOVIEW_H__D5E9B2AD_710E_11D3_9047_00104B264545__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "Led.h"

class CLedDemoView : public CView
{
protected: // create from serialization only
	CLedDemoView();
	DECLARE_DYNCREATE(CLedDemoView)

// Attributes
public:
	CLedDemoDoc* GetDocument();
	CLed m_Led;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLedDemoView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLedDemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLedDemoView)
	afx_msg void OnTestLedtestdialog();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in LedDemoView.cpp
inline CLedDemoDoc* CLedDemoView::GetDocument()
   { return (CLedDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LEDDEMOVIEW_H__D5E9B2AD_710E_11D3_9047_00104B264545__INCLUDED_)
