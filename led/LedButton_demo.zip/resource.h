//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by LedButtonDemo.rc
//
#define IDM_ABOUTBOX                   0x10
#define IDS_MULTI_LED_TOOLTIP           17
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DEMO_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDI_LIGHT_BULB_ON_ICON          129
#define IDI_LIGHT_BULB_OFF_ICON         132
#define IDI_LIGHT_BULB_BROKEN_ICON      133
#define IDI_GREEN_LED_ICON              135
#define IDI_GRAY_LED_ICON               136
#define IDI_RED_LED_ICON                137
#define IDI_YELLOW_LED_ICON             138
#define IDI_UNSURE_SMILY_ICON           139
#define IDI_ANGRY_SMILY_ICON            140
#define IDI_CRAZY_SMILY_ICON            141
#define IDI_HAPPY_SMILY_ICON            142
#define IDI_SICK_SMILY_ICON             143
#define IDI_BLUE_LED_ICON               144
#define IDC_MOOD_LED_CHECK              1000
#define IDC_BIT3_LED_CHECK              1001
#define IDC_CHANGE_BULB_BUTTON          1002
#define IDC_BIT2_LED_CHECK              1003
#define IDC_CONDITIONAL_LED_CHECK       1004
#define IDC_ACTIVITY_LED_CHECK          1005
#define IDC_BIT1_LED_CHECK              1007
#define IDC_BIT0_LED_CHECK              1009
#define IDC_BULB_STATIC                 1010
#define IDC_START_END_DEMO_BUTTON       1011
#define IDC_COUNTER_EDIT                1015
#define IDC_MULTI_ACTIVE_LED_CHECK      1016

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           1109
#endif
#endif
