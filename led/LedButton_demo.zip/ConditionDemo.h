//                                                                -*- C++ -*-
// ==========================================================================
//!
//! \file ConditionDemo.h
//!
//! \brief CConditionDemo Class.
//!
//! \author 
//!    Ricky Marek <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
//!
//!	\par Disclaimer
//!    This code and the accompanying files are provided <b>"as is"</b> with
//!    no expressed  or  implied warranty.  No responsibilities  for possible
//!    damages, or side effects in its functionality.  The  user must assume 
//!    the entire risk of using this code.  The author accepts no  liability
//!    if it causes any damage to your computer, causes your pet to fall ill, 
//!    increases baldness or makes your car  start  emitting  strange noises 
//!    when you start it up.  <i>This code  has no bugs,  just  undocumented 
//!    features!.</i>
//!
//! \par Terms of use
//!    This code is <b>free</b> for personal use, or freeware applications as
//!    long as this comment-header  header remains like this.  If you plan to 
//!    use  this  code in  a commercial  or shareware  application,   you are 
//!    politely  asked  to  contact the author for his permission via e-mail. 
//!    From: <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
//!
//! \par Attributes
//!    \li \b Created       21/Dec/2002
//!    \li \b Last-Updated  22/Dec/2004
//!    \li \b Compiler      Visual C++
//!    \li \b Requirements  Win98/Win2k or later, MFC.
//!    \li \b Tested        with Visual C++ 7.1(.NET 2003)
//!
//!
// ==========================================================================
#ifndef _CCONDITIONDEMO__H_ // _CCONDITIONDEMO__H_
#define _CCONDITIONDEMO__H_ // _CCONDITIONDEMO__H_


// ///////////////////////////////////////////////////////////////////////////
// Header Files
// ///////////////////////////////////////////////////////////////////////////
#include "LedButton.h"

/**
 * \ingroup LedButtonDemo
 *
 * \brief CConditionDemo Class
 *
 * \par requirements
 * win2k or later\n
 * MFC\n
 *
 * \author Ricky Marek <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
 *
 *
 */
class CConditionDemo : public CLedStateCondition
{
public:
    CConditionDemo(void);
    virtual ~CConditionDemo(void) {};     ///< Default Destructor: Do nothing.

    /** Enumerated type for denote a bulb-light state. */
    enum EBulbState
    {
        BULB_OFF = LED_BUTTON_STATE_OFF,  ///< Bulb light is off, healthy
        BULB_ON,                          ///< Bulb light is on, healthy
        BULB_BURNED,                      ///< Bulb light is burned.

        BULB_STATE_SENTINEL               ///< Not to be used as Bulb State.
    };

    /*!
     * Decide which \a newLedState to change according to the \a oldLedState.
     * 
     * The return value will deppend on the number of times the Led State
     * changes from "Off" to "On". If this number is greater than the bulb
     * lifetime, the return value will be CConditionDemo::BULB_BURNED.
     *
     * \param newLedState is the requested new LedState.
     * \param oldLedState the current LedState before the transition.
     * \param isForcedChange a boolean flag that may be used to force a transtition.
     *        The effect is the same as changing the bulb with a simillar bulb.
     *
     * \return the nee LedState the LedButton will show.
     */
    virtual LedState ChangeState(LedState newLedState, 
                                 LedState oldLedState, 
                                 bool isForcedChange=false);

    /**
     * Change the current bulb with a healty bulb light.
     * \param bulbLifeTime the life time of the new bulb light.
     */
    void ChangeBulb(int bulbLifeTime);

    /** \name Getters */
    //@{
    /** Get the times this bulb was turned on (transition from off to on) */
    int GetTurnOnCounter(void) { return(m_bulbTurnOnCount); }

    /** Get the lifetime of the bulb. */
    int GetBulbLifeTime(void) { return(m_bulbLifeTime); }

    /** Get the reminding life of the bulb. */
    int GetRemainingLifeCounter(void) { return(m_bulbLifeTime -m_bulbTurnOnCount); };
    //@}

private:
    int m_bulbLifeTime;         ///< The bulb-light life time
    int m_bulbTurnOnCount;      ///< Number of times the bulb was turned on.

};

#endif // _CCONDITIONDEMO__H_

//
// --- No-code-allowed-beyond-this-line--------------------------------------
//
