//                                                                -*- C++ -*-
// ==========================================================================
//!
//! \file ConditionDemo.cpp
//!
//! \brief Implementation of the CConditionDemo Class.
//!
//! \author 
//!    Ricky Marek <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
//!
//!	\par Disclaimer
//!    This code and the accompanying files are provided <b>"as is"</b> with
//!    no expressed  or  implied warranty.  No responsibilities  for possible
//!    damages, or side effects in its functionality.  The  user must assume 
//!    the entire risk of using this code.  The author accepts no  liability
//!    if it causes any damage to your computer, causes your pet to fall ill, 
//!    increases baldness or makes your car  start  emitting  strange noises 
//!    when you start it up.  <i>This code  has no bugs,  just  undocumented 
//!    features!.</i>
//!
//! \par Terms of use
//!    This code is <b>free</b> for personal use, or freeware applications as
//!    long as this comment-header  header remains like this.  If you plan to 
//!    use  this  code in  a commercial  or shareware  application,   you are 
//!    politely  asked  to  contact the author for his permission via e-mail. 
//!    From: <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
//!
//! \par Attributes
//!    \li \b Created       22/Dec/2002
//!    \li \b Last-Updated  22/Dec/2004
//!    \li \b Compiler      Visual C++
//!    \li \b Requirements  Win98/Win2k or later, MFC.
//!    \li \b Tested        with Visual C++ 7.1(.NET 2003)
//!
//!
// ==========================================================================


// ///////////////////////////////////////////////////////////////////////////
// Header Files
// ///////////////////////////////////////////////////////////////////////////
#include "StdAfx.h"
#include "ConditionDemo.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


// ///////////////////////////////////////////////////////////////////////////
// CConditionDemo Constructor
// ///////////////////////////////////////////////////////////////////////////
CConditionDemo::CConditionDemo(void)
{
    m_bulbLifeTime = 5;
    m_bulbTurnOnCount = 0;
}


// ///////////////////////////////////////////////////////////////////////////
// ChangeBulb
// ///////////////////////////////////////////////////////////////////////////
void CConditionDemo::ChangeBulb(int bulbLifeTime)
{
    m_bulbLifeTime = bulbLifeTime;
    m_bulbTurnOnCount = 0;

}


// ///////////////////////////////////////////////////////////////////////////
// ChangeState
// ///////////////////////////////////////////////////////////////////////////
LedState CConditionDemo::ChangeState(LedState newLedState, 
                                     LedState oldLedState, 
                                     bool isForcedChange /*=false*/)
{
    if (isForcedChange)
    {
        m_bulbTurnOnCount = 0;
        return(newLedState);
    }

    if (oldLedState < newLedState)
    {
        m_bulbTurnOnCount++;
    }
    
    if (m_bulbLifeTime == m_bulbTurnOnCount)
    {
        m_bulbTurnOnCount = m_bulbLifeTime;
        newLedState = 2; // Burn State.
    }

    return(newLedState);
}

//
// --- No-code-allowed-beyond-this-line--------------------------------------
//
