//                                                                -*- C++ -*-
// ==========================================================================
//!
//! \file LedButtonDemo.h
//!
//! \brief main header file for the LedButtonDemo application
//!
//! \author 
//!    Ricky Marek <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
//!
//!	\par Disclaimer
//!    This code and the accompanying files are provided <b>"as is"</b> with
//!    no expressed  or  implied warranty.  No responsibilities  for possible
//!    damages, or side effects in its functionality.  The  user must assume 
//!    the entire risk of using this code.  The author accepts no  liability
//!    if it causes any damage to your computer, causes your pet to fall ill, 
//!    increases baldness or makes your car  start  emitting  strange noises 
//!    when you start it up.  <i>This code  has no bugs,  just  undocumented 
//!    features!.</i>
//!
//! \par Terms of use
//!    This code is <b>free</b> for personal use, or freeware applications as
//!    long as this comment-header  header remains like this.  If you plan to 
//!    use  this  code in  a commercial  or shareware  application,   you are 
//!    politely  asked  to  contact the author for his permission via e-mail. 
//!    From: <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
//!
//! \par Attributes
//!    \li \b Created       21/Dec/2002
//!    \li \b Last-Updated  22/Dec/2004
//!    \li \b Compiler      Visual C++
//!    \li \b Requirements  Win98/Win2k or later, MFC.
//!    \li \b Tested        with Visual 7.1(.NET 2003)
//!
//!
// ==========================================================================
#ifndef LEDBUTTONDEMO__H_ // LEDBUTTONDEMO__H_
#define LEDBUTTONDEMO__H_ // LEDBUTTONDEMO__H_

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


// CLedButtonDemoApp:
// See LedButtonDemo.cpp for the implementation of this class
//

class CLedButtonDemoApp : public CWinApp
{
public:
	CLedButtonDemoApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CLedButtonDemoApp theApp;

#endif // LEDBUTTONDEMO__H_

