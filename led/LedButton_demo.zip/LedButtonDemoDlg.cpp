//                                                                -*- C++ -*-
// ==========================================================================
//!
//! \file LedButtonDemoDlg.cpp
//!
//! \brief Implementation of the CLedButtonDemoDlg and CAbout Classes.
//!
//! \author 
//!    Ricky Marek <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
//!
//!	\par Disclaimer
//!    This code and the accompanying files are provided <b>"as is"</b> with
//!    no expressed  or  implied warranty.  No responsibilities  for possible
//!    damages, or side effects in its functionality.  The  user must assume 
//!    the entire risk of using this code.  The author accepts no  liability
//!    if it causes any damage to your computer, causes your pet to fall ill, 
//!    increases baldness or makes your car  start  emitting  strange noises 
//!    when you start it up.  <i>This code  has no bugs,  just  undocumented 
//!    features!.</i>
//!
//! \par Terms of use
//!    This code is <b>free</b> for personal use, or freeware applications as
//!    long as this comment-header  header remains like this.  If you plan to 
//!    use  this  code in  a commercial  or shareware  application,   you are 
//!    politely  asked  to  contact the author for his permission via e-mail. 
//!    From: <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
//!
//! \par Attributes
//!    \li \b Created       21/Dec/2002
//!    \li \b Last-Updated  22/Dec/2004
//!    \li \b Compiler      Visual C++
//!    \li \b Requirements  Win98/Win2k or later, MFC.
//!    \li \b Tested        with Visual 7.1(.NET 2003)
//!
//!
// ==========================================================================
#include "stdafx.h"
#include "LedButtonDemo.h"
#include "LedButtonDemoDlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define WM_TOGGLE_TIMER                 (WM_USER + 100)
#define WM_ACTIVITY_LED_TIMER           (WM_USER + 101)
#define WM_MULTI_ACTIVITY_LED_TIMER     (WM_USER + 102)

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()



CLedButtonDemoDlg::CLedButtonDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLedButtonDemoDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    m_toggleLedTimer = NULL;
    m_isDemoRunning = false;
    m_counter = 0;
}

void CLedButtonDemoDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_MOOD_LED_CHECK, m_moodLedCtrl);
    DDX_Control(pDX, IDC_ACTIVITY_LED_CHECK, m_activityLedCtrl);
    DDX_Control(pDX, IDC_CONDITIONAL_LED_CHECK, m_conditionalLedCtrl);
    DDX_Control(pDX, IDC_START_END_DEMO_BUTTON, m_startEndDemoBtn);
    DDX_Control(pDX, IDC_BIT0_LED_CHECK, m_bitLeds[0]);
    DDX_Control(pDX, IDC_BIT1_LED_CHECK, m_bitLeds[1]);
    DDX_Control(pDX, IDC_BIT2_LED_CHECK, m_bitLeds[2]);
    DDX_Control(pDX, IDC_BIT3_LED_CHECK, m_bitLeds[3]);
    DDX_Control(pDX, IDC_MULTI_ACTIVE_LED_CHECK, m_multiLedCtrl);
}

BEGIN_MESSAGE_MAP(CLedButtonDemoDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
    ON_WM_DESTROY()
    ON_WM_TIMER()
    ON_BN_CLICKED(IDC_CHANGE_BULB_BUTTON, OnChangeBulbBnClicked)
    ON_BN_CLICKED(IDC_START_END_DEMO_BUTTON, OnStartEndDemoBnClicked)
END_MESSAGE_MAP()


// CLedButtonDemoDlg message handlers

BOOL CLedButtonDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

    for(int ledIndex = 0; ledIndex < 4; ledIndex++)
    {
        m_bitLeds[ledIndex].SetIcons(IDI_GRAY_LED_ICON, IDI_GREEN_LED_ICON);
    }

    m_moodLedCtrl.SetLedStatesNumber(MOOD_STATE_SENTINEL);
    m_moodLedCtrl.SetIcon(UNSURE_MOOD, IDI_UNSURE_SMILY_ICON, 32,32);
    m_moodLedCtrl.SetIcon(HAPPY_MOOD, IDI_HAPPY_SMILY_ICON, 32,32);
    m_moodLedCtrl.SetIcon(CRAZY_MOOD, IDI_CRAZY_SMILY_ICON, 32,32);
    m_moodLedCtrl.SetIcon(SICK_MOOD, IDI_SICK_SMILY_ICON, 32,32);
    m_moodLedCtrl.SetIcon(ANGRY_MOOD, IDI_ANGRY_SMILY_ICON, 32,32);
    m_moodLedCtrl.SetTextForeground(ANGRY_MOOD, RGB(200,0,0));

    m_activityLedCtrl.SetIcons(IDI_GRAY_LED_ICON, IDI_GREEN_LED_ICON);
    m_activityLedCtrl.SetLedActivityTimer(WM_ACTIVITY_LED_TIMER);

    m_multiLedCtrl.SetLedStatesNumber(LIGHT_STATE_SENTINEL);
    m_multiLedCtrl.SetIcon(GRAY_LIGHT, IDI_GRAY_LED_ICON);
    m_multiLedCtrl.SetIcon(GREEN_LIGHT, IDI_GREEN_LED_ICON);
    m_multiLedCtrl.SetIcon(RED_LIGHT, IDI_RED_LED_ICON);
    m_multiLedCtrl.SetIcon(BLUE_LIGHT, IDI_BLUE_LED_ICON);
    m_multiLedCtrl.SetIcon(YELLOW_LIGHT, IDI_YELLOW_LED_ICON);
    m_multiLedCtrl.SetLedActivityTimer(WM_MULTI_ACTIVITY_LED_TIMER, 500);
    m_multiLedCtrl.SetTooltipText(IDS_MULTI_LED_TOOLTIP);

    m_conditionalLedCtrl.SetLedStatesNumber(CConditionDemo::BULB_STATE_SENTINEL);
    m_conditionalLedCtrl.SetIcon(CConditionDemo::BULB_OFF, IDI_LIGHT_BULB_OFF_ICON,24,24);
    m_conditionalLedCtrl.SetIcon(CConditionDemo::BULB_ON, IDI_LIGHT_BULB_ON_ICON,24,24);
    m_conditionalLedCtrl.SetIcon(CConditionDemo::BULB_BURNED, IDI_LIGHT_BULB_BROKEN_ICON,24,24);
    m_conditionalLedCtrl.SetLedStateCondition(&m_condition);

    CString text;
    text.Format("Remain %d times to be turned on...", m_condition.GetRemainingLifeCounter());
    GetDlgItem(IDC_BULB_STATIC)->SetWindowText(text);
    text.Format("Toggle State on timer event.\nBurn after %d turn-on times.", m_condition.GetBulbLifeTime());
    m_conditionalLedCtrl.SetWindowText(text);
    m_conditionalLedCtrl.SetTooltipText(text);
    
    GetDlgItem(IDC_COUNTER_EDIT)->SetWindowText("");
    m_startEndDemoBtn.SetWindowText("Start Demo");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CLedButtonDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CLedButtonDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CLedButtonDemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CLedButtonDemoDlg::OnDestroy()
{

    CDialog::OnDestroy();
    
    if (NULL != m_toggleLedTimer)
    {
        KillTimer(m_toggleLedTimer);
        m_toggleLedTimer = NULL;
    }
}

void CLedButtonDemoDlg::OnStartEndDemoBnClicked()
{
    m_startEndDemoBtn.EnableWindow(FALSE);

    if (NULL != m_toggleLedTimer)
    {
        KillTimer(m_toggleLedTimer);
        m_toggleLedTimer = NULL;
    }

    if (m_isDemoRunning)
    {
        m_isDemoRunning = false;
        m_startEndDemoBtn.SetWindowText("Continue Demo");
        m_startEndDemoBtn.EnableWindow(TRUE);
        GetDlgItem(IDC_COUNTER_EDIT)->SetWindowText("");

        return;
    }

    m_isDemoRunning = true;
    m_counter = 0;
    m_startEndDemoBtn.SetWindowText("Pause Demo");
    m_toggleLedTimer = SetTimer(WM_TOGGLE_TIMER, 500, NULL);

    GetDlgItem(IDC_COUNTER_EDIT)->SetWindowText("0");
    m_startEndDemoBtn.EnableWindow(TRUE);
}

void CLedButtonDemoDlg::OnTimer(UINT nIDEvent)
{
    if (WM_TOGGLE_TIMER == nIDEvent)
    {
        m_counter++;

        m_activityLedCtrl.SetLedState(GREEN_LIGHT);

        for(int ledIndex = 0; ledIndex < 4; ledIndex++)
        {
            m_bitLeds[ledIndex].SetLedState((m_counter & (1L << ledIndex)) ? GREEN_LIGHT : GRAY_LIGHT);
        }

        if (0 == (m_counter % 3))
        {
            // Mood Led.
            LedState ledState = m_moodLedCtrl.GetLedState() +1;
            if (ledState == MOOD_STATE_SENTINEL)
            {
                ledState = UNSURE_MOOD;
            }
            m_moodLedCtrl.SetLedState(ledState);
            m_multiLedCtrl.SetLedState(((m_counter/3) % (LIGHT_STATE_SENTINEL-1)) +1);
        }


        m_conditionalLedCtrl.SetLedState((m_counter & 0x2) ? CConditionDemo::BULB_ON : CConditionDemo::BULB_OFF);

        CString text = _T("Bulb is burned and needs to be changed.");
        if (m_condition.GetRemainingLifeCounter() != 0)
        {
            text.Format("Remain %d times to be turned on...", m_condition.GetRemainingLifeCounter());
        }
        GetDlgItem(IDC_BULB_STATIC)->SetWindowText(text);
        m_conditionalLedCtrl.SetTooltipText(text);
        text.Format("Toggle State on timer event.\nBurn after %d turn-on times.", m_condition.GetBulbLifeTime());
        m_conditionalLedCtrl.SetWindowText(text);

        text.Format("%d", m_counter);
        GetDlgItem(IDC_COUNTER_EDIT)->SetWindowText(text);

        return;
    }

    CDialog::OnTimer(nIDEvent);
}


void CLedButtonDemoDlg::OnChangeBulbBnClicked()
{
    int lifeTime = m_condition.GetBulbLifeTime() + 1;
    m_conditionalLedCtrl.SetLedState(CConditionDemo::BULB_OFF, true);
    m_condition.ChangeBulb(lifeTime);

    CString text;
    text.Format("New Bulb(lifetime=%d)",lifeTime);
    m_conditionalLedCtrl.SetWindowText(text);

    m_conditionalLedCtrl.SetLedState(CConditionDemo::BULB_OFF, true);
    GetDlgItem(IDC_BULB_STATIC)->SetWindowText("");

    // TODO: Add your control notification handler code here
}


