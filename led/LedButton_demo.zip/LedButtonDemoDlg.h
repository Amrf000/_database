//                                                                -*- C++ -*-
// ==========================================================================
//!
//! \file LedButtonDemoDlg.h
//!
//! \brief CLedButtonDemoDlg Class.
//!
//! \author 
//!    Ricky Marek <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
//!
//!	\par Disclaimer
//!    This code and the accompanying files are provided <b>"as is"</b> with
//!    no expressed  or  implied warranty.  No responsibilities  for possible
//!    damages, or side effects in its functionality.  The  user must assume 
//!    the entire risk of using this code.  The author accepts no  liability
//!    if it causes any damage to your computer, causes your pet to fall ill, 
//!    increases baldness or makes your car  start  emitting  strange noises 
//!    when you start it up.  <i>This code  has no bugs,  just  undocumented 
//!    features!.</i>
//!
//! \par Terms of use
//!    This code is <b>free</b> for personal use, or freeware applications as
//!    long as this comment-header  header remains like this.  If you plan to 
//!    use  this  code in  a commercial  or shareware  application,   you are 
//!    politely  asked  to  contact the author for his permission via e-mail. 
//!    From: <A HREF="mailto:ricky.marek@gmail.com">ricky.marek@gmail.com</A>
//!
//! \par Attributes
//!    \li \b Created       21/Dec/2002
//!    \li \b Last-Updated  22/Dec/2004
//!    \li \b Compiler      Visual C++
//!    \li \b Requirements  Win98/Win2k or later, MFC.
//!    \li \b Tested        with Visual C++ 7.1(.NET 2003)
//!
//!
// ==========================================================================
#ifndef LEDBUTTONDEMODLG__H_ // LEDBUTTONDEMODLG__H_
#define LEDBUTTONDEMODLG__H_ // LEDBUTTONDEMODLG__H_


// ///////////////////////////////////////////////////////////////////////////
// Header Files
// ///////////////////////////////////////////////////////////////////////////
#include "LedButton.h"
#include "AfxWin.h"
#include "ConditionDemo.h"


// CLedButtonDemoDlg dialog
class CLedButtonDemoDlg : public CDialog
{
public:
	CLedButtonDemoDlg(CWnd* pParent = NULL);	// standard constructor


	enum { IDD = IDD_DEMO_DIALOG }; ///< Dialog Data

    afx_msg void OnDestroy();
    afx_msg void OnTimerCheckBnClicked();
    afx_msg void OnTimer(UINT nIDEvent);
    afx_msg void OnChangeBulbBnClicked();
    afx_msg void OnStartEndDemoBnClicked();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

	HICON m_hIcon;

private:
    enum EMoodState
    {
        UNSURE_MOOD = LED_BUTTON_STATE_OFF,
        HAPPY_MOOD,
        CRAZY_MOOD,
        SICK_MOOD,
        ANGRY_MOOD,

        MOOD_STATE_SENTINEL  ///< Not to be used as Mood State.
    };

    enum ELightState
    {
        GRAY_LIGHT =  LED_BUTTON_STATE_OFF,
        GREEN_LIGHT,
        RED_LIGHT,
        YELLOW_LIGHT,
        BLUE_LIGHT,

        LIGHT_STATE_SENTINEL ///< Not to be used as Light State.
    };

    CLedButton m_bitLeds[4];
    CLedButton m_moodLedCtrl;
    CLedButton m_activityLedCtrl;
    CLedButton m_multiLedCtrl;
    CLedButton m_conditionalLedCtrl;
    CButton m_startEndDemoBtn;
    UINT_PTR  m_toggleLedTimer;
    CConditionDemo m_condition;
    bool m_isDemoRunning;
    int m_counter;
};

#endif // LEDBUTTONDEMODLG__H_
//
// --- No-code-allowed-beyond-this-line--------------------------------------
//
